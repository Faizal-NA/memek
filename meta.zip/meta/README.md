# Metode Login SC
````php
1. Token FB EAAB
2. Convert Cookie ke Token EAAB
````
# Fitur Crack
````php
01. Crack Teman Publik
02. Crack Random ID Massal
03. Checkpoint Detedtor
04. Cek Hasil Crack
05. Info Update SC
00. Logout (Hapus Token/Cookie)
````
# Metode Crack
````php
Metode (free)
Metode (mbasic)
Metode (mobile)
````
# Perintah Menjalankan SC
````php
$ pkg update && pkg upgrade
$ pkg install python git
$ pip install requests bs4 futures
$ pip install cython
$ rm -rf meta
$ termux-setup-storage
$ git clone https://github.com/ROY-ID/meta
$ cd meta
$ git pull
$ python run.py
````
